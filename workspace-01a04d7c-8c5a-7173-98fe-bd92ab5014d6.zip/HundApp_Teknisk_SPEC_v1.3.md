# 🐾 HundApp – Teknisk SPEC v1.6

**Status:** Komplett produkt- och teknisk specifikation  
**Datum:** 29 augusti 2026  
**Arkitekturstatus:** 10 sammanlänkade moduler, 1 centraliserad stilmall (`styles.css`), 1 centraliserad skriptmodul (`app.js`).

> **Aktuellt avgränsningsbeslut – Fas 1 (GitHub Pages & Klientprototyp):**  
> Den aktuella versionen är en **100 % självförsörjande, fullt interaktiv och responsiv webbapplikation** optimerad för statisk hosting på **GitHub Pages**. All funktionalitet (kontoskapande, Google-inloggning, hundprofiler, promenadlogg, kalender, statistik och förslagsröstning) fungerar direkt i användarens webbläsare med säker `localStorage`-persistens. Produkter (`products.html`), e-handelskoppling och betalsystem skjuts upp till Fas 4 enligt produktplanen.

---

## 1. Fullständig översikt över prototypens 10 levererade moduler

1. **Publik startsida (`index.html` + `app.js`):**
   - **Modern Responsiv Hero:** Skandinavisk design med dubbla CTA-knappar (*Skapa gratis konto* och *Testa demo*), trust-märken samt en fullt klickbar app-mockup.
   - **Live Statistikstrip:** Snittbetyg från hundägare (`— / 5` som uppdateras live vid inskickade recensioner), `25+` Kvalitetssäkrade tips, `100 %` Fokus på hundglädje, `0 kr` Gratis grundversion.
   - **Dynamisk Recensionsmotor (`#reviews`):** Startar tomt och uppdateras direkt i realtid via modal (`#review-modal`).
   - **Community-omröstning & FAQ:** Interaktiv röstning om aktivering och utfällbara FAQ-frågor.

2. **Evidensbaserat Tipsbibliotek (`tips.html` + `app.js`):**
   - **25 Expertgranskade hundtips:** Fördelade på 5 huvudkategorier (*Hälsa 1–5, Träning 6–10, Vardag 11–15, Foder & Kost 16–20, Valp 21–25*).
   - **Interaktiv Sök & Kategorifiltrering:** Med debounce, dynamisk resultaträknare, favoritmarkering och genomförandestatus.
   - **Fulltext Modal:** Fördjupade råd med källhänvisningar (SVA, Jordbruksverket, SKK, SLU).

3. **Interaktiv Promenad- & Aktivitetslogg (`walks.html` + `app.js`):**
   - **Promenadloggare & Typväljare:** Snabba typ-pills (*Skogspromenad*, *Kvarterspromenad*, *Långpromenad*), distans (km), tid (minuter) och anteckningar.
   - **Aktivitetsloggare:** Registrering av nosaktivering, lydnadsträning, lek och agility.
   - **Live Metrikkort:** Sammanlagda promenader, total aktivitetstid och total distans som uppdateras live per hund.

4. **Hundhälsa, Viktjournal & Statistikmotor (`statistics.html` + `app.js`):**
   - **Interaktiva SVG-grafer:** Veckovis stapeldiagram för promenader och donut-diagram för aktivitetsfördelning.
   - **Viktjournal & Trendindikator:** Snabbmodal för vägning, målvikt och historik.
   - **Utskriftsvänlig Journal (`window.print()`):** Genererar en ren översikt inför veterinärbesök.

5. **Hundportalen – Daglig Dashboard (`portal.html` + `app.js`):**
   - **Hundhälsning & Datum:** Automatisk dagsöversikt med aktiv hunds namn och ålder.
   - **Daglig Rutinchecklista:** Interaktiva kryssrutor för kloklippning, fästingmedel och veterinärkontroll med sparad status.
   - **Foder- & Allergenprofil:** Snabböversikt över förbjudna ingredienser och känslig mage.
   - **Hundbytare (Multi-Dog Switcher):** Byt sömlöst mellan t.ex. Bella och Max.

6. **Hundprofiler, Chip-ID & Vaccinationsjournal (`dogs.html` + `app.js`):**
   - **Fullständiga Hundprofiler:** Golden Retriever Bella (28,5 kg) och Fransk Bulldogg Max (12,8 kg).
   - **Klickbar Chip-ID-kopiering:** Ett klick kopierar microchipnumret direkt till urklipp med toast-bekräftelse.
   - **Vaccinationspass:** Status och giltighetsdatum för DHPPI, Rabies, Leptospiros och Kennelhosta.
   - **Skapa / Redigera Hund Modal:** Komplett formulär för att lägga till nya hundar eller uppdatera befintliga.

7. **Aktivitetskalender & Rutinpåminnelser (`calendar.html` + `app.js`):**
   - **Interaktiv Månadsnavigering:** Föregående/nästa månad, "Idag"-knapp och tydlig datumväljare.
   - **Månadsvy & Agendalista:** Växla mellan grafisk månadskalender och kronologisk agendalista.
   - **Kategorifilter & Färgkodade Piller:** Skötsel (blå), Hälsa (grön), Veterinär (lila), Träning/Aktivitet (orange) och Födelsedag (rosa/guld).
   - **Dynamiska Årliga Födelsedagar med Åldersberäkning:** Skapar automatiskt födelsedagshändelse i rätt månad med automatisk beräkning av hur gammal hunden blir.
   - **Schemaläggningsmodal med Intervall:** Lägg till återkommande rutiner (varje vecka, var 3:e vecka, månadsvis, årsvis).

8. **Förslagslåda & Idéröstning (`suggestions.html` + `app.js`):**
   - **25 Community-förslag (25b):** Pre-populerat bibliotek med 25 efterfrågade funktioner.
   - **Interaktiv Röstningsmotor:** Uppåt-röstning (`▲ Rösta`) som ökar räknaren direkt och sparar användarens röststatus i `localStorage`.
   - **Förslagsformulär & Maila Admin:** Skapa nya förslag som publiceras direkt på omröstningsbrädan och skickar automatiskt en färdigformaterad kopia till administratörens inkorg via `mailto:admin@hundapp.se`.
   - **Sortering & Statusfilter:** Sortera på *Flest röster*, *Nyaste*, *A-Ö* och filtrera på status (*I utveckling*, *Planerat*, *Under granskning*, *Genomfört*, *Nytt*).

9. **Autentisering & Säkerhet (`login.html` & `register.html` + `app.js`):**
   - **Skapa konto / Logga in:** Både manuell registrering med e-post/lösenord samt 1-klicks inloggning via Google (Google OAuth-simulering).
   - **Lösenordsstyrkemätare:** Visuell mätare för längd, versaler/gemener, siffror och specialtecken.
   - **Kom ihåg mig & Demoinloggning:** Sparar e-post lokalt samt snabbknapp för direkt inloggning i demoläge.
   - **Glömt lösenord-modal & Villkorsmodaler:** Komplett återställningsflöde och visning av integritetspolicy.

10. **Central Motor (`app.js`) & Enhetlig Design (`styles.css`):**
    - 14 strukturerade sektioner, `safeStorage`, XSS-sanering, debounce, flerspråkighet (SV/EN) och snabb DOM-reaktivitet.

---

## 2. Kommande funktioner i Roadmap (Fas 2)

Följande funktioner har prioriterats upp från communityns förslagslåda och lagts till i specifikationen som kommande moduler:

1. ☀️ **Asfalttemperatur & Sommarvarning (120 röster):**
   - *Beskrivning:* Inbyggd algoritm och integration mot väder-API som varnar när solen och lufttemperaturen gör asfalten brännhet (över 50°C).
   - *Funktion:* Visar en varningstriangel på startsidan/portalen under varma sommardagar med råd om att välja skuggiga skogsstigar samt ett "7-sekunders asfalttest".
   - *Status:* **Kommande / Fas 2 (Genomförs efter baslansering)**.

2. 🎆 **Ljudträning mot Nyårsraketer & Åska (145 röster):**
   - *Beskrivning:* Träningsmodul för gradvis desensibilisering och motbetingning för skotträdda och ljudkänsliga hundar.
   - *Funktion:* Inbyggd ljudspelare med kalibrerade ljudnivåer för fyrverkerier, åska och trafikljud kopplat till en 4-veckors träningsplan och belöningsschema.
   - *Status:* **Kommande / Fas 2**.

3. 🐕 **SOS Hundpassning & Promenadkompisar (112 röster):**
   - *Beskrivning:* Geografisk matching för lokala hundägare som söker sällskap på promenader eller behöver akut avlastning vid sjukdom eller övertid.
   - *Funktion:* Verifierade användarprofiler med hundstorlek, lekmönster och kompatibilitet (t.ex. tik/hane, leksugen/lugn senior).
   - *Status:* **Kommande / Fas 2 (Kräver backend-databas för direktmeddelanden)**.

4. 📸 **Hundens Personliga Journalbok (Minnen & Foto) (81 röster):**
   - *Beskrivning:* Digital foto- och minnesdagbok för att föreviga hundens liv från valp till senior.
   - *Funktion:* Ladda upp foton för första snön, valpkursens diplom, 1-årsdagen och favoritbadplatsen med tidslinjevy och exportmöjlighet.
   - *Status:* **Kommande / Fas 2**.

---

## 3. Kompatibilitetsanalys för GitHub Pages (100 % Funktionsgaranti)

### Hur fungerar appen på GitHub Pages just nu?
Applikationen är konstruerad som en **statisk Single-Page/Multi-Page Web Application (JAMstack)**:
- **100 % Kompatibel med GitHub Pages:** Inga Node/Python-servrar krävs vid körning; alla filer (`.html`, `.css`, `.js`) serveras direkt över HTTPS med snabb CDN-hastighet.
- **Fullt fungerande Konton & Sessioner:**
  - När en besökare skapar ett konto eller klickar på "Fortsätt med Google" sparas sessionen omedelbart i webbläsarens `localStorage`.
  - Användaren loggas in, navigeras till `portal.html` och deras namn, hundar och loggar hålls synkade mellan sidorna.
- **Fullt fungerande Hunddata, Promenader & Kalender:**
  - Besökare kan lägga till egna hundar, logga promenader, schemalägga rutiner i kalendern och skriva recensioner. Allt sparas lokalt på besökarens enhet.
- **Fullt fungerande Förslag & Röstning:**
  - Användare kan rösta på de 25 förslagen (rösterna uppdateras och sparas lokalt så att man inte kan dubbelrösta).
  - Skickar användaren in ett nytt förslag publiceras det direkt på röstningsbrädan och öppnar ett förformaterat mail till `admin@hundapp.se`.

### Steg för att publicera på GitHub:
1. Skapa ett GitHub-repository (t.ex. `hundapp`).
2. Ladda upp alla filer från arbetsytan till `main`-branchen.
3. Gå till **Settings** > **Pages** i repot, välj `Branch: main` / `Folder: / (root)` och klicka på **Save**.
4. Sidan är live inom 30 sekunder på `https://<användarnamn>.github.io/hundapp/`.

### Nästa steg för fullständig molnsynkning (Fas 3):
När du senare vill att två olika familjemedlemmar ska kunna logga in på samma hund från två olika mobiler samtidigt kan en molndatabas (t.ex. **Supabase**, **Firebase Auth/Firestore** eller **REST API**) kopplas in i `app.js` genom att byta ut `safeStorage`-anropen mot API-anrop (`fetch('/api/...')`). Frontend-gränssnittet är redan 100 % förberett för detta!
